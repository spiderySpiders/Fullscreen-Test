
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Main extends JFrame {

	JPanel panel;
	JLabel label;
//	JButton button;
	Container con;
//	ButtonListener bList;
	
	int screenHeight = 300, screenWidth = 300;
	int screenX, screenY;
	
	public static void main(String[] args) {
		System.out.println("Testing");
		new Main();
		
	}
	
	public void init() {
		screenHeight = getHeight();
		screenWidth = getWidth();
		// But 136 here?
		screenX = getX();
		screenY = getY();
		System.out.println("Screen X: " + screenX + 
				"\nScreen Y: " + screenY + "\nScreen height: " 
				+ screenHeight + "\nScreen width: " + screenWidth);
		
		panel = new JPanel();
		panel.setBounds(screenX, screenY, screenHeight, screenWidth);
		panel.setBackground(Color.blue);
		
		
		System.out.println("JPanel made");
		
		label = new JLabel("It should be the size of the window!");
		label.setForeground(Color.red);
		panel.add(label);
//		Haha it wasn't needed :)
//		button = new JButton("Resize screen."); 
//		button.setBackground(Color.red);
//		button.setForeground(Color.black);
//		button.addActionListener(bList);
//		button.setActionCommand("reSize");
//		button.setFocusPainted(false);
//		panel.add(button);
//		
//		System.out.println("JButton made");
		con = getContentPane();
		con.setLayout(new GridLayout(1, 1));
		
		System.out.println("Container made");
		
		con.add(panel);
		setVisible(true);
	}
	
	public Main() {
		setTitle("Fullscreen Test");
		setSize(screenWidth, screenHeight);
//		System.out.println("" + screenWidth); It's 100 here?
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		setLocationRelativeTo(null);
		setVisible(true);
		init();
	}
	
//	public class ButtonListener implements ActionListener {
//		
//		//Not needed?
//
//		@Override
//		public void actionPerformed(ActionEvent e) {
//		// TODO Auto-generated method stub
//			
//			String buttonPress = e.getActionCommand();
//			
//			System.out.println("Screen X: " + screenX + 
//					"\nScreen Y: " + screenY + "\nScreen height: " 
//					+ screenHeight + "\nScreen width: " + screenWidth);
//			
//			switch(buttonPress) {
//			case "reSize": break;
//			}
//		
//		}
//	}
}
